/*
 * File: Extension.java
 * Name: 
 * Section Leader: 
 * ----------------------
 * This file is the starter file for the DrawCenteredRect problem.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Extension extends GraphicsProgram {

	public void run() {
		/* You optinally fill this in. */
	}
}

