/*
 * File: Flight.java
 * Will eventually represent a particular flight between 
 * two locations.
 */
public class Flight {
	//TODO: Implement me!
}
